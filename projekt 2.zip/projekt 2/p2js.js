
init = () => {
    console.log("ok");
    sac();
}
sac = () => {
    let ko = 0;
    let its = document.querySelectorAll('[data-soundnr]');
    console.log(its);
    for (let i = 0; i < its.length; i++) {
        its[i].addEventListener('click', function (e) {
            let audio = new Audio('audio/' +its[i].dataset.soundnr + '.mkv');
            
            audio.pause();
            audio.currentTime = 0;

            audio.play();
            console.log(ko);
            
        })
        console.log(its[i].dataset.soundnr);
    }
}


window.addEventListener('load', init);